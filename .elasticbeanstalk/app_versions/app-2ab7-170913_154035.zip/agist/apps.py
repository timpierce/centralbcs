from django.apps import AppConfig


class AgistConfig(AppConfig):
    name = 'agist'
    verbose_name = 'Faith Path'
